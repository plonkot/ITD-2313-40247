# As the three projects this week are so similar, I'm going to combine them all
#   into a single file. Also, since the concepts of estimating the square root
#   are explained - or at least mentioned - in the case study on pages 92-95, I
#   won't really be going into too much depth there.
# I will attempt to look at some of the concepts of this particular example, as
#   they might be a bit confusing to newer programmers, but overall, the com-
#   mentary on this project will be minimal.
# The first thing we will do is import the math module, since we will be dis-
#   playing Python's calculation of the square root of the number.

import math

# Next, we will setup the tolerance value for the estimation. As this is a con-
#   stant value that should never change throughout the program, I will use all
#   caps for the variable name. This is not a requirement, but it is a common
#   programming convention to use all caps for constant names. If you want a
#   more accurate estimation, you will use a smaller value: i.e. 0.000000001
#   will be more accurate than 0.000001.

TOLERANCE = 0.000001

# Since I'm going to be using the same value for the initial estimation, I'm
#   going to setup a constant for that, too. This is not necessary, but since
#   all functions use this value, it's just better programming convention to do
#   so.

ESTIMATE = 1.0

# This is the first of three newton functions. This is the closest to the exam-
#   ple found in the case study mentioned before. By and large, this is all
#   just copied from that case study and setup as a function instead of just
#   something that runs in the terminal. The only thing this does NOT do is get
#   the input from the user, as this will be done in the main() function. At
#   the end of the function, we return the value to the calling function (in
#   this case, main()).

def newton_1(value):
    # As tolerance is defined above, we do not need to redefine it here, but we
    #   do need to set the initial estimate to our established value.
    
    estimate = ESTIMATE

    # This is just the case study formula. I use 'value' instead of 'x' for
    #   personal reasons, but 'x' would be fine here, as well.
    
    while True:
        estimate = (estimate + value / estimate) / 2
        difference = abs(value - estimate ** 2)
        if difference <= TOLERANCE:
            break
        
    return estimate

# In newton_2(), we set this up as a recursive function, which is, simply put,
#   a function that calls itself. This can be used to reduce the use of "while
#   True" loops. For this particular recursive function, we are accepting a
#   value, which we will receive from the user, and an estimate, which we will
#   not. So, when we call this function from the main() function, we will need
#   to pass in some default value. We will use 1.0. We could, in theory, ask
#   the user for an estimate, which could speed up the program slightly, but
#   we don't need to do that if we just pass in an arbitrary default value,
#   like 1.0. Otherwise, the calculation used here is exactly the same as be-
#   fore.

def newton_2(value, estimate):
    estimate = (estimate + value / estimate) / 2
    difference = abs(value - estimate ** 2)

    # Here is where the recursion is established. You will notice that if the
    #   differenec is within the tolerance value, we return the estimate. If it
    #   is not (the else statement), we return the value of the function, pass-
    #   in the value and the calculated estimate. This works just like the
    #   "while True" loop we used in newton_1.
    
    if difference <= TOLERANCE:
        return estimate
    else:
        return newton_2(value, estimate)

# In newton_3(), this is setup exactly like newton_2() with the exception that
#   we are using a default argument for the estimate. This means we can call
#   this function with either one or two arguments when calling it. If we pass
#   in one argument, it will be the value we're trying to estimate the square
#   root of, and if we pass in two arguments, the first will be the value, and
#   the second will be the estimate. In the first case (one argument), the est-
#   imate will be assigned a default value of 1.0. Otherwise, this works exact-
#   ly like newton_2().

def newton_3(value, estimate = ESTIMATE):
    estimate = (estimate + value / estimate) / 2
    difference = abs(value - estimate ** 2)

    if difference <= TOLERANCE:
        return estimate
    else:
        return newton_3(value, estimate)

def main():
    while True:
        # Present the user with a reason they're entering a value and what you
        #   are planning on doing with that value. Also, describe how to end
        #   the program. I save this value as a string first, so I can check
        #   to see if the user entered nothing. After I make that check, I will
        #   cast the entry as a float to pass to the newton functions.
        
        print("Enter a positive number to estimate the square root.")
        x = input("(Hit Enter without a number to exit): ")

        if x == "":
            break

        value = float(x)

        # Display Python's calculation
        
        print("Python's result:", math.sqrt(value))

        # Now, we will display the three functions' estimations. These should
        #   all be the same, since we're using the same calculation for each
        #   one. A few things of note:
        # newton_1() only takes one argument, since it only accepts one argu-
        #   ment. The initial estimation is set within the function in its
        #   first line.
        # newton_2() takes two arguments, since it is setup to accept two argu-
        #   ments. We have to pass in an arbitrary value here, so I am picking
        #   1.0, which is the same value that is setup in newton_1().
        # newton_3() can take either one or two arugments, but since I do not
        #   have an actual estimate, I'm not going to pass one in. When the
        #   function is called from within the recursive function, it will be
        #   called with an argument there.
        # If you want to experiment a little, you can adjust the initial est-
        #   imations to see how the estimations differ. For instance, change
        #   the estimation to 2.0 and check the square root of 4. Compare the
        #   estimations to when you use 1.0 as the default estimation. Isn't
        #   that interesting?
        
        print("newton_1's estimation:", newton_1(value))
        print("newton_2's estimation:", newton_2(value, ESTIMATE))
        print("newton_3's estimation:", newton_3(value))

        # Add a blank line for the sake of clarity.
        
        print()

# Call the main() function if the module is run.

if __name__ == "__main__":
    main()
