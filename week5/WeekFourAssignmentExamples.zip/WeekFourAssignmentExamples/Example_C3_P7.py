# I feel as though this program is much simpler than program 6 for this chap-
#   ter. All we need here is some basic information from the user: a starting
#   salary, which will be a float; the amount of increase, which I'll address
#   in just a moment; and the number of years, as an int.
# There are really two ways to get the amount of increase here. You can get it
#   as a whole number and divide by 100, which is the method I will be showing
#   in this example, or you can have the user enter the value as a decimal. For
#   instance, a 2% increase will be entered as 0.02. I prefer NOT to do things
#   this way because it requires the user to do the math on their own, and if
#   there is one thing you should learn early on in your programming life, it's
#   that you should strive to make things as simple as possible for your end
#   users in order to avoid confusion and potential errors. However you decide
#   to do it, though, just make sure that it's clearly stated in your display
#   to the end user.
# Let's go ahead and collect this information now:

salary = float(input("What is the starting salary for the teacher? "))

# Note: when I ask for the increase, I do this in two lines, as this should
#   make things a little more clear for the user. I also put the "input" func-
#   tion on the second line - not the line where I'm actually asking the ques-
#   tion. I do this because if I put it on the line where I ask the question,
#   it will stop the program and wait for input BEFORE the user is shown the
#   example values.

print("What is the annual percentage increase?")
increase = float(input("(For instance 2 or 2.5) "))

years = int(input("How many years has the teacher been teaching? "))

# The next tricky part is formatting the table properly, so it looks nice. This
#   will take some fiddling around to get it right, but what you generally want
#   is going to be columns that are all the same width with headers. You can
#   use other elements like the pipe character ( | ) and hyphens ( - ) to help
#   make things look more tabular, but that's not exactly necessary. There is
#   an example of how to make tabular data on pages 75-76 of the text.
# Let's start with the headers. The "years" column is going to be pretty narrow
#   on this, and the salary is the only other column we need.

print("%5s | %10s" % ("Years", "Salary"))

# And, because I like to separate my headers from the data, a line of hyphens.
#   Again, just kind of tinker around until you get a look that you like.
print("------|-----------")

# Now comes the part where we loop through the years and find our teachers'
#   salary. We start with year 1. Remeber when we start a loop, Python starts
#   with 0, so we will want to display the value of the count + 1 and not just
#   the count. Then we display the salary. After that we will calculate the new
#   salary by multiplying the salary by the increase percentage divded by 100
#   (Note: if you got the increase as a percent, you will not further divide by
#   100) and then add this calculation to the current salary. And, that's
#   pretty much the entire loop. Let's tate a look!

for count in range(years):
    print("%5d | $%9.2f" % (count + 1, salary))

    salary += salary * (increase / 100)

# And, that's it!
