# This program can be a little tricky, so let's break down what we will need as
#   we go through this one. Before we begin, though, just so you know there are
#   many different ways to go about this program, and this is just one way. If
#   you have other ways that work, that's perfectly fine.
# To start, we need to look at the things that change in this program. What I
#   mean by that is given the information we know, what changes occur that we
#   need to account for when writing the program. Let's consider the formula
#   provided:
#
# pi / 4 = 1 - 1/3 + 1/5 - 1/7 ...
#
# I see two things that change each iteration of the loop. Take a moment and
#   see if you can pick up on two things that would change each iteration of
#   the loop.
# If you said the denominator of each fraction and the arithmetic operation,
#   you're on the right track! So, what can we do with this information?
# Well, for the denominator, let's look at how it changes. We add a value of 2
#   to the denominator each time, right? You might be thinking "what about the
#   first value of 1?", and that's a good thought. But, what could be another
#   way to write a value of 1 using the other values in the equation as a
#   guide? How about 1/1? So if we use 1/1, 1/3, 1/5, 1/7, and so on, then we
#   can safely add 2 to it each iteration. For the math part of this, we will
#   then divide one by this number.
# Based on this, we will be creating a variable to hold the denominator of our
#   fractions
# The other thing that changes is the arithmetic operation. We go back and\
#   forth between adding and subtracting, starting with subtraction after the
#   first 1/1. However, we also need to start with adding the initial 1/1 to
#   our total, so we will actually start with adding. In other words, our total
#   is going to start with a value of 0.0, and the first thing we're going to
#   do is add 1/1 to that. Then, the next time, we're going to subtract 1/3
#   from that value.
# But, how do we manage that? Think about it for a moment and see if you can
#   come up with a way to switch back and forth between to operations.
# The easiest way for me to think about this is by creating a variable that
#   holds a Boolean value (True or False) and performs an operation based on
#   that variable's value. For instance, if the variable is True, we add;
#   otherwise, we subtract. Then, at the end of the loop, we switch the vari-
#   able to the other value.
# What other information do we need for this? According to the text, we only
#   need the number of iterations of this process. Then we display the esti-
#   mation. So, let's start with creating our variables to hold the denominator
#   and mathematical operation and get some input from the user. While we're at
#   it, we will also create the variable that holds the total value.

denominator = 1
addition = True
total = 0.0

iterations = int(input("How many iterations would you like to run? "))

# The loop setup is pretty standard. We're going to use the number of itera-
#   tions as the loop control, and inside the loop we're going to do the simple
#   task of checking to see if we need to add or subtract from the total the
#   value of 1 divided by the denominator.
# After that, we add 2 to the denominator, as we discussed above, and we assign
#   of value of the opposite of the current addition Boolean variable to it-
#   self. We do this by assigning it the value of "not" addition. When dealing
#   with Booleans, this is a really common way to switch a Boolean back and
#   forth in loops like this.
for count in range(iterations):
    if addition:
        total += 1 / denominator
    else:
        total -= 1 / denominator

    denominator += 2
    addition = not addition

# Remember that our formula calculates the value of pi / 4, so we need to
#   multiply the value we have by 4, so we can assign that value to our pi that
#   we want to display.
pi = total * 4

# Finally, just a quick display, so we can see that the program worked.
print("The estimated value of pi after", iterations, "iterations is", pi)

# As a side note, it takes this formula around 750 iterations to get close to
#   pi to the second decimal place, 2,000 to get to the third decimal place,
#   20,000 to get to the fourth, 400,000 to get to the fifth, and almost 2
#   million to get to the sixth decimal place. While, in theory, this program
#   can keep going for some time to create more accurate estimations, I do
#   no recommend running it for more than about 100 million iterations. Based
#   on the strength of your computer, it really starts to take some time at
#   more than 100 million (12.4 seconds on my computer).
# Running a billion iterations took my computer 2 minutes, 4.6 seconds to get
#   a result of 3.1415926525880504, which is accurate up to the eighth decimal
#   place, which isn't that much more accurate than 2 million iterations.
