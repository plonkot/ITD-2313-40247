# The first thing we want to do is get some input. This has been done multiple
#   times throughout the course so far, so I won't go too far into it. From the
#   assignment, we know we need the initial height of the ball and the number
#   of times the ball will be allowed to bounce. Let's get those now.

# The height will be a float because when we multiply it by the bounce adjust-
#   ment, it will eventually turn into a float, so it's best to just set it up
#   as one from the get go.

height = float(input("How high is the ball you're dropping? "))

# The number of bounces will be an int becaues we're only bouncing the ball in
#   whole numbers.

bounces = int(input("How many times will the ball bounce? "))

# Now, let's set up the bounce adjustment. It's good programming practice to
#   create variables and use those instead of hard coding in your values. I
#   will be using all caps on this variable name to denote that this is a con-
#   stant value that should not be changed by the program at any time.

ADJUSTMENT = 0.6

# Finally, I'm going to setup a variable to hold the total distance traveled.
#   This is the variable that we will accumulate our total distances to while
#   the program is doing its calculations. Again, this is a floating-point val-
#   ue and will start at 0.0.

distance = 0.0

# Now that we have our setup completed, we're ready to actually do the work of
#   the program. To start with, we're going to setup a loop. This loop will ex-
#   ecute the number of times that we want our ball to bounce. This is a pretty
#   easy thing to setup, so I'm not going to go in-depth with this.
# Once we have the loop setup, our calculations are going to go as follows:
# * First we add the height of the ball to the existing distance. This is be-
#   cause the ball has to fall first.
# * Next, we calculate how far the ball will bounce back up by multiplying the
#   height by the adjustment. We assign this value to the height variable be-
#   cause this is how high the ball will be at the end of this "bounce".
# * Finally, we add the new height value to the total distance traveled.
# When the loop starts its next iteration, the "height" of the ball will be the
#   new value, so this gives us what we want. Let's look at the code for this
#   now.

for count in range(bounces):
    distance += height
    height *= ADJUSTMENT
    distance += height

# And, that's it! The only thing left is to display the total distance.

print("The ball traveled", distance, "units of distance.")
