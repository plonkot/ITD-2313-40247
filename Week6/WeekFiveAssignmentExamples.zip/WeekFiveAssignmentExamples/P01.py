# This is a pretty easy project. We're going to ask the user for three sides
#   of a triangle, and then we're going to compare the lengths of the sides.
#   The definition of an equilateral triangle is a triangle that has three e-
#   qual sides and three equal angles. Thus, if we get three sides of a tri-
#   angle, and they're all the same, we know we have an equilateral triangle.
# By certain mathematical principles, we know that if a is equal to be and b is
#   equal to c, then a is equal to c. We will use that to our advantage.
# Normally, I wouldn't want to name variables with single letters like this,
#   but in this case, it's easy enough to manage with these simple variable
#   names. Getting these values is simple enough.

a = float(input("Enter the length of side a: "))
b = float(input("Enter the length of side b: "))
c = float(input("Enter the length of side c: "))

# Now, we just have to compare the lengths of the sides. As I said earlier, if
#   a and b are the same and b and c are the same, a and c are the same. This
#   is a simple if statement. If that's not true, our triangle in not equilat-
#   eral. That takes care of our else statement. Print out appropriate output.

if a == b and b == c:
    print("This is an equilateral triangle!")
else:
    print("This is not an equilateral triangle.")

