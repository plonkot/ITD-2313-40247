# This final example is really more just about understading the math than it is
#   understanding the programming logic. But, first, let's list all of the com-
#   ponents that we will be looking for, so it'll be easier for us to lay ever-
#   ything out.
# According to the text, we only need one input: the amound of the initial pur-
#   chase. That's easy. Since money is usually in dollars and cents, we pro-
#   bably want to use a float for this. Easy.
# The rest of the information is provided for us:
# * The down payment is 10% of the total purchase price.
# * The annual interest rate is 12% (of the remaining balance).
# * Monthy payments are 5% of the purchase price minus the down payment.
# * To calculate the interest for one month, multiply the starting balance by
#   the interest rate and divide that by 12. 
# * We need a table, with headers, that shows us a bunch of information, in-
#   cluding:
#   * Month number
#   * Starting balance for that month
#   * The interest owed for the month
#   * The principal for the month
#   * The payment for the month
#   * The ending balance for that month
# Now, some of these figures will be the same for all months, and some will
#   change each month. For the figures that will be the same for all months or
#   are only used once, we want to calculate those BEFORE the loop, and if the
#   amount changes each month, we want to do that calculation inside the loop.
# So, let's look at what can be done before the loop, and what needs to be done
#   inside the loop.
# Before the loop can be the initial purchase, down payment, initial balance
#   after down payment, and monthly payments.
# Iside the loop we need to calculate the monthly interest, the principal, and
#   the ending balance. We will also get the month's starting balance from the
#   previous iteration of the loop.
# Let's start by setting some constant values. These values will not change
#   while the program runs, but if we wanted to see some other results, we can
#   adjust these before running the program. These values are taken from the
#   textbook. Remember that a percent is a value over 100, so 10% is 0.10, and
#   so on and so forth.

DOWN_PAYMENT_RATE = 0.10
INTEREST_RATE = 0.12
MONTHLY_PAYMENT = 0.05

# Now, I'm going to setup a variable to count the number of months the loan is
#   expected to take. I am starting this at 1 (since 1 is the first month), and
#   I will increment it in the loop each time it runs.

month = 1

# Just getting the amount of the loan from the user and assigning it to a vari-
#   able. There are a few thoughts behind this, as some people would just ass-
#   ign this to a balance variable and work from there, but I might want to use
#   the initial loan amount later on, so I'm going to save it as its own vari-
#   able, just in case.

initial_loan = float(input("How much will your loan be? "))

# Now, we will calculate the values that we determined we can calculate before
#   the loop. I believe these assignments are pretty self-explanatory, so I'm
#   not going to go too deep into this part of it.

down_payment = initial_loan * DOWN_PAYMENT_RATE
balance = initial_loan - down_payment
payment = balance * MONTHLY_PAYMENT

# This is the header of the table. It's important to try to keep in mind how
#   large of numbers you'll be dealing with, so you make sure to leave yourself
#   enough space for them in your layout. For instance, the Balance will likely
#   be less than $9,999,999.99, which will be shown as $9999999.99 on the tab-
#   le. This is 10 digits, including the decimal point. This means when we get
#   to formatting out output string, we will wan to use 10.2f for this value.
#   Once we add the dollar sign and a space on both sides for ease of reading,
#   our balance will take 13 total spaces. Now yours might be different, and
#   that's fine. As long as you can tell the headers go with which information
#   in the table.

print("Month |   Balance   | Interest | Principal |  Payment  |    Ending")
print("------|-------------|----------|-----------|-----------|------------")

# Now, let's get to our loop. We're going to keep this loop going while we
#   still have an active balance. Once the balance reaches 0, we want the loop
#   to end.

while balance > 0:
    # One of the things we will need in our table is the starting balance. So,
    #   I'm going to create a variable called "start" to hold this value.
    
    start = balance

    # Now, I'm going to calculate the interest, using the interest rate and the
    #   formula from the text. Easy-peasy.

    interest = balance * INTEREST_RATE / 12

    # This is just a quick thing to see if the payment will take the balance
    #   below zero. We don't want to overcharge our customer and have to refund
    #   him/her, so if the payment amount is greater than the starting balance
    #   plus the interest for the month, we're going to adjust the payment for
    #   this month to the balance plus the interest.
    # As an example, if our monthly payment is $100, and the balance going into
    #   the final month is $20 with $5 interest, we want to set the payment for
    #   this month to $25 dollars instead of the normal $100.
    # Note: this was not required by the textbook, but I think it's a nice
    #   Quality of Life adjustment.

    if payment > balance + interest:
        payment = balance + interest

    # Now we calculate the principal by subtracting the interest amount from
    #   the starting balance. We then subtract the principal payment amount
    #   from the balance and reassign that value to the balance variable to
    #   give us our ending balance.
    
    principal = payment - interest
    balance -= principal

    # We now have all of the information we need to setup our table. This takes
    #   some messing around to get it all right, but the general look should be
    #   something similar to this.

    print("%5d | $%10.2f | $%7.2f | $%8.2f | $%8.2f | $%10.2f" %
          (month, start, interest, principal, payment, balance))

    # Increment the month variable, so the next iteration of the loop will show
    #   a different month.
    
    month += 1

# And, that's that!
