# On this twist of the classic "guessing game", we are tasked to create a pro-
#   gram where the computer is the one trying to guess our number. Now, there
#   are different ways to set this up. We could set this up, so the computer
#   thinks more like a human if we wanted to.
# For instance, if I were to tell you to guess a number I have in my head be-
#   tween 1 and 100, you would almost definitely pick 50 first to see if the
#   number was higher or lower than that, and then you would pick something
#   like 25 or 75, depending on the answer.
# This is called the "Binary Search" pattern, where you slice whatever group
#   you have to search through in two right down the middle, and you continue
#   this process until you find your number. This is one of the quickest ways
#   to search through large chunks of data, and it's a pretty important one
#   that's used in a lot of programming.
# So, how do we set this up? Well, let's think through all of the things we
#   will need first. We're going to need a range of numbers to guess between.
#   The text has us enter these values as part of the program, so that's easy
#   enough. We need to limit the number of guesses the computer will take. The
#   text asks us to use the log2 value of the range of guesses. This means we
#   will need the math module to get the log function. And, that's about it! We
#   don't really need more than that other than our logic throughout the pro-
#   gram, so let's start by importing math and getting our values.
# Always remember that you can important specific functions from a module, as
#   this does reduce the overhead in your programs slightly. For these smaller
#   example programs, it's not really that important to do, though.

import math

low = int(input("What is the low number of the range? "))
high = int(input("What is the high number of the range? "))

# Just to make sure that our high number is greater than our low number, I'm
#   going to do a simple check and swap if the need is there. This is because,
#   by and large, I do not trust my end users to give me correct information.
#   I explained how this works in the previous project example, so I won't do
#   it again here.

if low > high:
    temp = low
    low = high
    high = temp

# Now, we want to know the range of numbers available for the computer to guess
#   from. Let's think about how to get this value. If we were to say guess a
#   number between 1 and 10, we would just know that there are 10 number from
#   which we can guess, right? And, if we were to guess a number between 1 and
#   100, we konw that's 100 numbers, right? Yet, when we subtract 1 from 10 or
#   1 from 100, we get 9 and 99, respectively. So, there's really two ways to
#   get our actual range from here. We can either subtact 1 from the low number
#   or add 1 to the total value. Most people would choose to add 1 to the total
#   value, as it's easier to write. Let's do that and assign the result to a
#   variable.

guess_range = (high - low) + 1

# Note that you do not actally need the parentheses here, but I like to include
#   them for readability.
# Now, we're going to determine how many guesses the computer has to get our
#   number. The text asks us to use the log2 value of the range of values to
#   get this, and this makes sense. The log2 value of a number is basically the
#   the number that, when squared, you will get the original value. For in-
#   stance, the log2 of 9 is 3, and the log2 of 100 is 10. This value will work
#   for us as a base number of guesses becaues we're going to be cutting our
#   range in half each time we guess, and it will take us about the log2 value
#   of guesses to get the value we want from there. Since the log is going to
#   be a float, we want to round that value to an int.

max_guesses = round(math.log(guess_range, 2))

# There are several ways to go about this. The way I like to do this is to cre-
#   are a for loop, using the max guesses as the range of my loop. This will
#   mean that the computer will only guess at my number the set number of times
#   at most and then concede defeat. It will also claim you cheated if it loses
#   because using the Binary Search like this should always get you to the
#   correct answer in equal to or less than log2 of a value. But, just in case,
#   we're going to create a Boolean variable and assign it an initial value of
#   false. This will only change if the computer gets the number right.

got_it = False

# This is just a little quality of life (QoL) step to tell you to pick a number
#   and make sure you're ready for the computer to start guessing. I'm only
#   using the input function here to stop the program and wait. I don't actual-
#   ly need any input from the user, so I'm not assigning the input to any var-
#   iable.

print("Pick a number between %d and %d. Press enter when ready, and I will guess."
      % (low, high))
input("Press enter to continue")

# Now, we have the loop that really controls the game. Since I am using a for
#   loop, I set it up to use the range of "max_guesses" as the number of times
#   the loop will execute. That's the easy part.
# The first thing the loop does is make a guess. It does this by adding the
#   high and low values together, dividing that by 2 and rounding down. For ex-
#   ample, if the range is 1-10, we would add those values together to get 11,
#   divided that by 2 (5.5), and round down to 5. This will be the starting
#   point for guessing.

for count in range(max_guesses):
    guess = (low + high) // 2

    # We will now display the guesss to the user and ask the user if that
    #   answer is correct. The important thing here is to make sure you tell
    #   the user what to enter for incorrect values. I am using 1 for too low,
    #   2 for too high, and any other value for a correct answer. I also added
    #   a QoL new-line character at the beginning, just to help break up the
    #   text a little.
    # Note that you ONLY use the input function on the last line. This is be-
    #   cause the program will stop each time it sees the input, so if you put
    #   input on the first line, it will stop after saying "Is your number..."
    #   without telling the user how to answer the question.

    print("\nIs your number %d?" % guess)
    print("Enter 1 if my guess is too low, 2 if my guess is too high,")
    answer = input(" or any other value if my guess is right. ")

    # Now we have the comparisons. If the user enters 1, we know the value is
    #   too low. If the user enters 2, we know the value is too high. If the
    #   user enters anything else, we know the computer is right. So, let's put
    #   together a series of if-else-if statements to reflect that.
    # The thing to pay attention to here is when the computer guesses a number
    #   lower or higher than our value, we need to adjust the computer's range,
    #   so it will know how to go from there. For instance, if the computer is
    #   guessing a number between 1 and 10, it's going to start with 5 every
    #   time. If 5 is too low, then the computer knows that the number will be
    #   between 6 and 10, right? So, we need to set the new "low" value to the
    #   guess plus 1. And similarly, if the guess is too high, we need to set
    #   the high value to the guess minus 1.
    # Also, again, just a little QoL with a new-line character and allowing the
    #   user to hit enter before continuing.

    if answer == "1":
        low = guess + 1
        input("\nRecalibrating and guessing again. Press Enter to continue.")
    elif answer == "2":
        high = guess - 1
        input("\nRecalibrating and guessing again. Press Enter to continue.")
    else:
        print("I GOT IT!!!")
        # Here we use "count + 1" for the correct number of tries because, if
        #   you remember, the for loop always starts with 0 and counts up to
        #   the range - 1.
        print("It only took me %d tries." % (count + 1))
        # If the computer gets the answer right, we set the got_it Boolean to
        #   True and break out of the loop
        got_it = True
        break;

# If the computer did not get the value, it will assume you cheated because the
#   Binary Search should, in theory, get the correct value in log2 guesses of a
#   range. However, this is demonstratably not true, as picking 4 or 7 in a
#   range between 1 and 10 will always fail. In larger ranges, though, this
#   should not fail.
if not got_it:
    print("I guess I ran out of guesses. Cheater.")
