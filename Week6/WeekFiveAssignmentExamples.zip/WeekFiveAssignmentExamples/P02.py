# This program starts out pretty similar to Project 1, so I won't go into that.
#   However, we will want to look at how we're going to solve the problem here,
#   so before we get too much further, let's look at that process.
# We know that, this is the formula we get from the Pythagorean Theorem:
#
# a^2 + b^2 = c^2 (a-squared plus b-squared is equal to c-squared).
#
# So, this means if we get the three sides of a triangle, we should be able to
#   add the squares of the shorter two sides to get the square of the third
#   side (the hypotenuse). Then, if we take the square root of that side, we
#   can get the length of the third side.
# Because we need to get a square root, we will first need to import the math
#   module. We could also import only the sqrt function from the module, but
#   I will generally import the entire math module when I need math.

import math

# Now, let's get the three sides' lengths. This is very much the same as we
#   have done before, so I won't cover it again.

a = float(input("Enter the length of side a: "))
b = float(input("Enter the length of side b: "))
c = float(input("Enter the length of side c: "))

# When we use the Pythagorean Theorem, we need to make sure that we're follow-
#   ing the formula properly. The "a" and "b" are the two shorter sides of the
#   triangle, and the "c" side is the longest. Because we never want to assume
#   our end user is going to enter values properly, we're going to take this
#   extra little step to ensure "a" and "b" are both smaller than "c". They
#   don't need to be fully sorted into ascending order, though; "c" just needs
#   to be the largest value.
# To do this, we're going to do a quick comparison of "a" and "c" and of "b"
#   and "c". If one of these values is larger than "c", we're going to just
#   swap the values. For instance, if our user enters 4, 5, and 3, we will
#   check to see if "a" (4) is bigger than "c" (3). Because it is, we will swap
#   the values of "a" and "c", so "c" will now be 4, and "a" will now be 3. We
#   then check "b" (5) and the new value of "c" (4) and perform the same swap
#   if "b" is larger than "c".
# The swap itself is pretty simple, but let's look at it a little more in-depth
#   for a moment. We can't just write a = c and c = a. This is because once we
#   assign the value of "c" to "a", they will hold the same value, so assigning
#   "a" to "c" after that will do nothing. So, instead what we have to do is
#   create a temporary variable to hold one of the values. In my case, I create
#   a variable called "temp" that will hold the current value of "a". Then I
#   assigned "a" the value of "c", and finished up by assigning "c" the value
#   "temp", which holds the original value of "a". I will put comments in the
#   following example using my earlier stated values of 4, 5, and 3 for "a",
#   "b", and "c", respectively, so you can see how the values are assigned.

if a > c:       # a is 4, b is 5, c is 3, temp does not exist yet
    temp = a    # a is 4, b is 5, c is 3, temp is 4
    a = c       # a is 3, b is 5, c is 3, temp is 4
    c = temp    # a is 3, b is 5, c is 4, temp is 4
                # a is 3, b is 5, c is 4, temp no longer exists

# And, again with "b" and "c"

if b > c:       # a is 3, b is 5, c is 4, temp does not exist again
    temp = b    # a is 3, b is 5, c is 4, temp is 5
    b = c       # a is 3, b is 4, c is 4, temp is 5
    c = temp    # a is 3, b is 4, c is 5, temp is 5
                # a is 3, b is 4, c is 5, temp no longer exists

# So, you can now see that "a" and "b" are not both smaller than "c", which
#   will allow us to properly use the Pythagorena Theorem.
# The next thing we will want to do calculate the value that we expect "c" to
#   be if this was a right triangle. We do this by performing the math on "a"
#   and "b" and setting the calculation to its own variable that I will call
#   "target" because it is the target value.
# Again, to calculate this target, we need to take the square root of "a"
#   squared plus "b" squared.

target = math.sqrt(a ** 2 + b ** 2)

# All that's left is comparing the "target" to the value of "c" that was pro-
#   vided by the user - or at least the largest value the user entered. If the
#   two values are equal, we have a right triangle, and we want to tell the
#   user that. If not, we want to tell the user it is not a right triangle.
# For example's sake, some example right triangle values are:
# * 3, 4, 5
# * 5, 12, 13
# * 7, 24, 25
# Also note that multiplying all values by the same number will also result in
#   a right triangle, so you can test the following similar-triangle values:
# * 15, 20, 25 (3, 4, 5 multiplied by 5)
# * 50, 120, 130 (5, 12, 13 multiplied by 10)
# * 1.68, 5.76, 6 (7, 24, 25 multiplied by 0.24)

if c == target:
    print("This is a right triangle!")
else:
    print("This is not a right triangle.")
